def linear_search(a, key):
    for i in range(len(a)):
        if a[i] == key:
            return i
    return -1

def binary_search(a, key):
    low, high = 0, len(a) - 1
    while low <= high:
        mid = (low + high) // 2
        if a[mid] == key:
            return mid
        elif key < a[mid]:
            high = mid - 1
        else:
            low = mid + 1
    return -1

ids = list(map(int, input("Enter account IDs: ").split()))
key = int(input("Enter ID to search: "))

print("Linear Search:", linear_search(ids, key))

sorted_ids = sorted(ids)
print("Sorted IDs:", sorted_ids)
print("Binary Search:", binary_search(sorted_ids, key))
