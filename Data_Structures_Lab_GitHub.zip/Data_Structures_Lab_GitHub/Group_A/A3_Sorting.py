def selection_sort(a):
    a = a.copy()
    n = len(a)
    for i in range(n - 1):
        min_index = i
        for j in range(i + 1, n):
            if a[j] < a[min_index]:
                min_index = j
        a[i], a[min_index] = a[min_index], a[i]
    return a

def bubble_sort(a):
    a = a.copy()
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:
            break
    return a

salaries = list(map(float, input("Enter salaries: ").split()))

s1 = selection_sort(salaries)
s2 = bubble_sort(salaries)

print("Selection Sort:", s1)
print("Bubble Sort:", s2)
print("Top five highest salaries:", sorted(salaries, reverse=True)[:5])
