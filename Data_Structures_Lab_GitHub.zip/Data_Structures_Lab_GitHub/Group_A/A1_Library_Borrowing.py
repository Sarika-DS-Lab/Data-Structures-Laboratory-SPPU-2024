def library_analysis(records):
    if not records:
        print("No borrowing records available.")
        return

    average = sum(records) / len(records)
    highest = max(records)
    lowest = min(records)
    zero_count = records.count(0)

    frequency = {}
    for value in records:
        frequency[value] = frequency.get(value, 0) + 1

    max_frequency = max(frequency.values())
    modes = [value for value, count in frequency.items()
             if count == max_frequency]

    print("Average books borrowed:", average)
    print("Highest borrowing:", highest)
    print("Lowest borrowing:", lowest)
    print("Students with zero borrowing:", zero_count)
    print("Mode:", modes)

records = list(map(int, input("Enter borrowing records: ").split()))
library_analysis(records)
