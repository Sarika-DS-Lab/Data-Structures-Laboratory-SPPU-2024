class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def insert(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert(root.left, key)
    elif key > root.key:
        root.right = insert(root.right, key)
    return root

def search(root, key):
    if root is None or root.key == key:
        return root
    if key < root.key:
        return search(root.left, key)
    return search(root.right, key)

def min_node(root):
    while root.left:
        root = root.left
    return root

def delete(root, key):
    if root is None:
        return None
    if key < root.key:
        root.left = delete(root.left, key)
    elif key > root.key:
        root.right = delete(root.right, key)
    else:
        if root.left is None:
            return root.right
        if root.right is None:
            return root.left
        successor = min_node(root.right)
        root.key = successor.key
        root.right = delete(root.right, successor.key)
    return root

def inorder(root):
    if root:
        inorder(root.left)
        print(root.key, end=" ")
        inorder(root.right)

root = None
for x in map(int, input("Enter keys: ").split()):
    root = insert(root, x)

print("Inorder:", end=" ")
inorder(root)
print()

key = int(input("Search key: "))
print("Found" if search(root, key) else "Not found")

key = int(input("Delete key: "))
root = delete(root, key)
print("After deletion:", end=" ")
inorder(root)
print()
