class CityNode:
    def __init__(self, city, population):
        self.city = city
        self.population = population
        self.left = None
        self.right = None

def insert(root, city, population):
    if root is None:
        return CityNode(city, population)
    if city < root.city:
        root.left = insert(root.left, city, population)
    elif city > root.city:
        root.right = insert(root.right, city, population)
    else:
        root.population = population
    return root

def search(root, city):
    comparisons = 0
    p = root
    while p:
        comparisons += 1
        if city == p.city:
            return p, comparisons
        p = p.left if city < p.city else p.right
    return None, comparisons

def min_node(root):
    while root.left:
        root = root.left
    return root

def delete(root, city):
    if root is None:
        return None
    if city < root.city:
        root.left = delete(root.left, city)
    elif city > root.city:
        root.right = delete(root.right, city)
    else:
        if root.left is None:
            return root.right
        if root.right is None:
            return root.left
        s = min_node(root.right)
        root.city, root.population = s.city, s.population
        root.right = delete(root.right, s.city)
    return root

def display_ascending(root):
    if root:
        display_ascending(root.left)
        print(root.city, root.population)
        display_ascending(root.right)

def display_descending(root):
    if root:
        display_descending(root.right)
        print(root.city, root.population)
        display_descending(root.left)

root = None
data = [("Pune", 7000000), ("Mumbai", 20000000), ("Delhi", 33000000),
        ("Nagpur", 3000000), ("Nashik", 2000000)]
for city, pop in data:
    root = insert(root, city, pop)

print("Ascending:")
display_ascending(root)
print("\nDescending:")
display_descending(root)

city = input("\nSearch city: ")
node, comparisons = search(root, city)
print("Found:", (node.city, node.population) if node else None)
print("Comparisons:", comparisons)
