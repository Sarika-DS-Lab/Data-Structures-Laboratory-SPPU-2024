class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def is_operator(ch):
    return ch in "+-*/%^"

def build_expression_tree(prefix):
    stack = []
    for ch in reversed(prefix):
        if ch.isspace():
            continue
        if not is_operator(ch):
            stack.append(Node(ch))
        else:
            left = stack.pop()
            right = stack.pop()
            node = Node(ch)
            node.left = left
            node.right = right
            stack.append(node)
    return stack[-1]

def postorder_non_recursive(root):
    if root is None:
        return []
    s1, s2 = [root], []
    while s1:
        node = s1.pop()
        s2.append(node)
        if node.left:
            s1.append(node.left)
        if node.right:
            s1.append(node.right)
    return [node.value for node in reversed(s2)]

def delete_tree(root):
    if root is None:
        return
    stack = [root]
    while stack:
        node = stack.pop()
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)
        node.left = None
        node.right = None

prefix = input("Enter prefix expression: ")
root = build_expression_tree(prefix)
print("Postorder:", " ".join(postorder_non_recursive(root)))
delete_tree(root)
root = None
print("Tree deleted.")
