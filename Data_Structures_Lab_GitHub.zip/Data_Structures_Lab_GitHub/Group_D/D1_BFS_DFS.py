from collections import deque

cities = ["A", "B", "C", "D", "E"]
edges = [("A","B"), ("A","C"), ("B","D"), ("C","D"), ("D","E")]

# Adjacency list
adj = {c: [] for c in cities}
for u, v in edges:
    adj[u].append(v)
    adj[v].append(u)

# Adjacency matrix
index = {c:i for i,c in enumerate(cities)}
matrix = [[0]*len(cities) for _ in cities]
for u, v in edges:
    matrix[index[u]][index[v]] = 1
    matrix[index[v]][index[u]] = 1

def bfs(start):
    visited = set([start])
    q = deque([start])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            if v not in visited:
                visited.add(v)
                q.append(v)
    return order

def dfs(start):
    visited = set()
    stack = [start]
    order = []
    while stack:
        u = stack.pop()
        if u in visited:
            continue
        visited.add(u)
        order.append(u)
        for v in reversed(adj[u]):
            if v not in visited:
                stack.append(v)
    return order

start = input("Start city (A-E): ").upper()
print("BFS:", bfs(start))
print("DFS:", dfs(start))
print("Adjacency Matrix:")
for row in matrix:
    print(row)
