import heapq

graph = {
    "Shop": [("A", 4), ("B", 2)],
    "A": [("Shop", 4), ("B", 1), ("C", 5)],
    "B": [("Shop", 2), ("A", 1), ("C", 8), ("D", 10)],
    "C": [("A", 5), ("B", 8), ("D", 2)],
    "D": [("B", 10), ("C", 2)]
}

def dijkstra(graph, source):
    dist = {v: float("inf") for v in graph}
    dist[source] = 0
    pq = [(0, source)]

    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue

        for v, weight in graph[u]:
            new_d = d + weight
            if new_d < dist[v]:
                dist[v] = new_d
                heapq.heappush(pq, (new_d, v))
    return dist

distances = dijkstra(graph, "Shop")
for city, time in distances.items():
    print(city, ":", time)
