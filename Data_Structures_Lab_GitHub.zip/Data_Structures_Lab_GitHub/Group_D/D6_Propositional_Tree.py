class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

operators = {"AND": 2, "OR": 2, "IMP": 2, "XOR": 2, "NOT": 1}

def build_from_postfix(tokens):
    stack = []
    for token in tokens:
        token = token.upper()
        if token not in operators:
            stack.append(Node(token))
        elif operators[token] == 1:
            child = stack.pop()
            node = Node(token)
            node.left = child
            stack.append(node)
        else:
            right = stack.pop()
            left = stack.pop()
            node = Node(token)
            node.left = left
            node.right = right
            stack.append(node)
    if len(stack) != 1:
        raise ValueError("Invalid postfix formula.")
    return stack[0]

def inorder(root):
    if root is None:
        return
    if root.left:
        print("(", end="")
    inorder(root.left)
    print(root.value, end=" ")
    inorder(root.right)
    if root.left:
        print(")", end="")

tokens = input("Enter postfix formula tokens, e.g. P Q AND R OR: ").split()
root = build_from_postfix(tokens)
print("Tree-based representation:")
inorder(root)
print()

# Complexity:
# Construction O(n), traversal O(n), auxiliary space O(n).
