# Quick Execution Guide

1. Install Python 3.x.
2. Open this repository folder in VS Code.
3. Open a program from Group_A, Group_B, Group_C or Group_D.
4. Click **Run Python File** (top-right) or open Terminal and run:
   `python Group_A/A1_Library_Borrowing.py`
5. Enter the values requested by the program.
6. For the external practical, be prepared to explain the data structure, algorithm, complexity and modifications.

All core programs use Python standard-library modules only.
