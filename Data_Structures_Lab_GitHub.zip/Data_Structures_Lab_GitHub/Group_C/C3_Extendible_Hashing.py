class Bucket:
    def __init__(self, depth, capacity=2):
        self.depth = depth
        self.capacity = capacity
        self.items = {}

class ExtendibleHash:
    def __init__(self, bucket_capacity=2):
        self.global_depth = 1
        self.capacity = bucket_capacity
        b0 = Bucket(1, bucket_capacity)
        b1 = Bucket(1, bucket_capacity)
        self.directory = [b0, b1]

    def _index(self, key):
        return hash(key) & ((1 << self.global_depth) - 1)

    def _double_directory(self):
        self.directory = self.directory + self.directory
        self.global_depth += 1

    def _split(self, index):
        old = self.directory[index]
        old_depth = old.depth
        if old_depth == self.global_depth:
            self._double_directory()

        new_depth = old_depth + 1
        new_bucket = Bucket(new_depth, self.capacity)
        old.depth = new_depth

        pattern = 1 << (new_depth - 1)
        for i, bucket in enumerate(self.directory):
            if bucket is old and (i & pattern):
                self.directory[i] = new_bucket

        items = list(old.items.items())
        old.items.clear()
        for k, v in items:
            self.directory[self._index(k)].items[k] = v

    def insert(self, key, value):
        while True:
            i = self._index(key)
            bucket = self.directory[i]
            if key in bucket.items:
                bucket.items[key] = value
                return
            if len(bucket.items) < bucket.capacity:
                bucket.items[key] = value
                return
            self._split(i)

    def search(self, key):
        return self.directory[self._index(key)].items.get(key)

    def delete(self, key):
        bucket = self.directory[self._index(key)]
        return bucket.items.pop(key, None) is not None

    def display(self):
        print("Global depth:", self.global_depth)
        for i, b in enumerate(self.directory):
            print(i, "depth", b.depth, b.items)

h = ExtendibleHash(2)
for k, v in [(1,"A"), (3,"B"), (5,"C"), (7,"D"), (9,"E")]:
    h.insert(k, v)
h.display()
print("Search 5:", h.search(5))
print("Delete 3:", h.delete(3))
h.display()
