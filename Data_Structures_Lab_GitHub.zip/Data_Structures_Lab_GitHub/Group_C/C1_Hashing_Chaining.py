TABLE_SIZE = 10
table = [[] for _ in range(TABLE_SIZE)]

def index(key):
    return key % TABLE_SIZE

def insert(key, value):
    i = index(key)
    for pair in table[i]:
        if pair[0] == key:
            pair[1] = value
            return
    table[i].append([key, value])

def search(key):
    for pair in table[index(key)]:
        if pair[0] == key:
            return pair[1]
    return None

def delete(key):
    bucket = table[index(key)]
    for i, pair in enumerate(bucket):
        if pair[0] == key:
            bucket.pop(i)
            return True
    return False

def display():
    for i, bucket in enumerate(table):
        print(i, ":", bucket)

insert(12, "A")
insert(22, "B")
insert(35, "C")
insert(17, "D")
display()

key = int(input("Search key: "))
print("Value:", search(key))

key = int(input("Delete key: "))
print("Deleted:", delete(key))
display()
