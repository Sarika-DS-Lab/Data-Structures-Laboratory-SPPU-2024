SIZE = 10
EMPTY = None
DELETED = object()
table = [EMPTY] * SIZE

def hash_index(key):
    return key % SIZE

def insert(key, value):
    start = hash_index(key)
    first_deleted = -1
    for step in range(SIZE):
        i = (start + step) % SIZE
        if table[i] is DELETED and first_deleted == -1:
            first_deleted = i
        elif table[i] is EMPTY:
            target = first_deleted if first_deleted != -1 else i
            table[target] = (key, value)
            return True
        elif table[i][0] == key:
            table[i] = (key, value)
            return True
    if first_deleted != -1:
        table[first_deleted] = (key, value)
        return True
    return False

def search(key):
    start = hash_index(key)
    for step in range(SIZE):
        i = (start + step) % SIZE
        if table[i] is EMPTY:
            return None
        if table[i] is not DELETED and table[i][0] == key:
            return table[i][1]
    return None

def delete(key):
    start = hash_index(key)
    for step in range(SIZE):
        i = (start + step) % SIZE
        if table[i] is EMPTY:
            return False
        if table[i] is not DELETED and table[i][0] == key:
            table[i] = DELETED
            return True
    return False

for key, value in [(12,"A"), (22,"B"), (32,"C"), (45,"D")]:
    insert(key, value)

print("Table:", table)
print("Search 22:", search(22))
print("Delete 22:", delete(22))
print("Table:", table)
