document = ""
undo_stack = []
redo_stack = []

def make_change(new_text):
    global document
    undo_stack.append(document)
    document = new_text
    redo_stack.clear()

def undo():
    global document
    if not undo_stack:
        print("Nothing to undo.")
        return
    redo_stack.append(document)
    document = undo_stack.pop()

def redo():
    global document
    if not redo_stack:
        print("Nothing to redo.")
        return
    undo_stack.append(document)
    document = redo_stack.pop()

while True:
    print("\n1. Make Change  2. Undo  3. Redo  4. Display  5. Exit")
    choice = int(input("Choice: "))

    if choice == 1:
        make_change(input("Enter new document state: "))
    elif choice == 2:
        undo()
    elif choice == 3:
        redo()
    elif choice == 4:
        print("Document:", document)
    elif choice == 5:
        break
    else:
        print("Invalid choice.")
