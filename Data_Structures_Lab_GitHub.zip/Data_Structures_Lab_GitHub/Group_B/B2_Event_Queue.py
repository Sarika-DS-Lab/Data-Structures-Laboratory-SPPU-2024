from collections import deque

q = deque()

while True:
    print("\n1. Add Event  2. Process Next Event  3. Display  4. Cancel Event  5. Exit")
    choice = int(input("Choice: "))

    if choice == 1:
        event = input("Enter event: ")
        q.append(event)
    elif choice == 2:
        if q:
            print("Processed:", q.popleft())
        else:
            print("Queue is empty.")
    elif choice == 3:
        print("Pending events:", list(q))
    elif choice == 4:
        event = input("Enter event to cancel: ")
        if event in q:
            q.remove(event)
            print("Event cancelled.")
        else:
            print("Event not found.")
    elif choice == 5:
        break
    else:
        print("Invalid choice.")
