class Node:
    def __init__(self, roll, name, marks):
        self.roll = roll
        self.name = name
        self.marks = marks
        self.next = None

class StudentList:
    def __init__(self):
        self.head = None

    def add(self, roll, name, marks):
        new = Node(roll, name, marks)
        if self.head is None:
            self.head = new
            return
        p = self.head
        while p.next:
            p = p.next
        p.next = new

    def display(self):
        p = self.head
        if p is None:
            print("List is empty.")
            return
        print("Roll\tName\tMarks")
        while p:
            print(p.roll, p.name, p.marks, sep="\t")
            p = p.next

    def search(self, roll):
        p = self.head
        while p:
            if p.roll == roll:
                print("Found:", p.roll, p.name, p.marks)
                return p
            p = p.next
        print("Not found.")
        return None

    def update(self, roll, name, marks):
        p = self.search(roll)
        if p:
            p.name, p.marks = name, marks
            print("Updated.")

    def delete(self, roll):
        if self.head is None:
            print("List is empty.")
            return
        if self.head.roll == roll:
            self.head = self.head.next
            print("Deleted.")
            return
        p = self.head
        while p.next and p.next.roll != roll:
            p = p.next
        if p.next:
            p.next = p.next.next
            print("Deleted.")
        else:
            print("Not found.")

    def sort(self, field, ascending=True):
        p = self.head
        while p:
            q = p.next
            while q:
                a = p.roll if field == "roll" else p.marks
                b = q.roll if field == "roll" else q.marks
                if (ascending and a > b) or ((not ascending) and a < b):
                    p.roll, q.roll = q.roll, p.roll
                    p.name, q.name = q.name, p.name
                    p.marks, q.marks = q.marks, p.marks
                q = q.next
            p = p.next

students = StudentList()

while True:
    print("\n1.Add 2.Delete 3.Update 4.Search 5.Display 6.Sort 7.Exit")
    ch = int(input("Choice: "))

    if ch == 1:
        students.add(int(input("Roll: ")), input("Name: "), float(input("Marks: ")))
    elif ch == 2:
        students.delete(int(input("Roll to delete: ")))
    elif ch == 3:
        students.update(int(input("Roll to update: ")), input("New name: "),
                        float(input("New marks: ")))
    elif ch == 4:
        students.search(int(input("Roll to search: ")))
    elif ch == 5:
        students.display()
    elif ch == 6:
        field = input("Sort by roll or marks: ").lower()
        order = input("Ascending or descending: ").lower()
        students.sort(field, order == "ascending")
    elif ch == 7:
        break
    else:
        print("Invalid choice.")
