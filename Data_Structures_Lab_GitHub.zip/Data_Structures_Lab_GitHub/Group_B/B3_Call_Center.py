from collections import deque

calls = deque()

def addCall(customer_id, call_time):
    calls.append((customer_id, call_time))
    print("Call added.")

def answerCall():
    if calls:
        customer_id, call_time = calls.popleft()
        print("Answering:", customer_id, "Call time:", call_time)
    else:
        print("No waiting calls.")

def viewQueue():
    if not calls:
        print("Queue is empty.")
    else:
        for customer_id, call_time in calls:
            print(customer_id, "at", call_time)

def isQueueEmpty():
    return len(calls) == 0

while True:
    print("\n1.Add 2.Answer 3.View 4.Is Empty 5.Exit")
    ch = int(input("Choice: "))

    if ch == 1:
        addCall(input("Customer ID: "), input("Call time: "))
    elif ch == 2:
        answerCall()
    elif ch == 3:
        viewQueue()
    elif ch == 4:
        print("Empty:", isQueueEmpty())
    elif ch == 5:
        break
    else:
        print("Invalid choice.")
