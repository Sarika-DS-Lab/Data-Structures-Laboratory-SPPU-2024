# Group E – Mini Project

Suggested application themes from the laboratory syllabus:
- Snake and Ladder using BFS
- Maze Generation using DFS
- Flight Reservation using Searching and Sorting
- Student Database Management using Hashing
- Job Scheduling using Graphs
- Palindrome Checker using Stacks and Queues
- Queue Using Two Stacks
- Keyword Frequency Counter using Hash Table
- Browser Back Button using Stack

Students should prepare a problem statement, objectives, theory, algorithm, flowchart, implementation, test cases and complexity analysis.
