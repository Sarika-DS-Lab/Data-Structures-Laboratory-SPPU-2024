# Data Structures Laboratory – SPPU 2024 Pattern

Python programs for PCC-204-COM Data Structures Laboratory.

## Folder Structure
- `Group_A/` – Lists, Searching, Sorting
- `Group_B/` – Stack, Queue, Linked List
- `Group_C/` – Hashing
- `Group_D/` – Graphs, Trees, Expression Trees
- `Group_E/` – Mini-project starter ideas

## Requirements
- Python 3.x
- VS Code (recommended) or IDLE
- No third-party packages are required.

## How to Run
1. Download/clone this repository.
2. Open the repository folder in VS Code.
3. Open the required `.py` file.
4. Click **Run Python File** or use the terminal: `python filename.py`.
5. Enter the test data requested by the program.

## External Practical Preparation
Understand the problem → identify the data structure → explain the algorithm → dry run → execute → test → state complexity → answer viva → modify the program if asked.

## Academic Note
These are instructional reference implementations for laboratory practice. Students should understand and be able to explain every statement before the practical examination.
